<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="ocean-opening" tilewidth="16" tileheight="16" tilecount="300" columns="20">
 <image source="ocean-opening.png" width="320" height="240"/>
</tileset>
